<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>howLong</name>
   <tag></tag>
   <elementGuidId>cd3db641-55a8-42c8-948d-09d4576b04c5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#loan-tenure > option:nth-child(5)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#loan-tenure > option:nth-child(5)</value>
   </webElementProperties>
</WebElementEntity>
