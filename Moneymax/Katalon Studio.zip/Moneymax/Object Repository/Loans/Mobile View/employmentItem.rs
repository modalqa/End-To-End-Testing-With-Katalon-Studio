<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>employmentItem</name>
   <tag></tag>
   <elementGuidId>5f68aaae-5619-4afb-a451-ecd5a48a48b6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#employer_status > #employer_status > option:nth-child(3)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#employer_status > #employer_status > option:nth-child(3)</value>
   </webElementProperties>
</WebElementEntity>
