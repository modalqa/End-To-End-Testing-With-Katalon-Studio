<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>menuLoan</name>
   <tag></tag>
   <elementGuidId>90acf7af-632c-46e7-990b-a42f0d63a6f5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#navbar > ul.nav.navbar-nav.navbar-custom > li:nth-child(3) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#navbar > ul.nav.navbar-nav.navbar-custom > li:nth-child(3) > a</value>
   </webElementProperties>
</WebElementEntity>
