<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>employmentStatus</name>
   <tag></tag>
   <elementGuidId>c1b9795d-1ae1-4553-a24c-50df13fe3a10</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#employer_status > option:nth-child(3)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#employer_status > option:nth-child(3)</value>
   </webElementProperties>
</WebElementEntity>
