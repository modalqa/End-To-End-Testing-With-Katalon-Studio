<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>buttonApply</name>
   <tag></tag>
   <elementGuidId>1ccc0916-ab6c-4f1e-bcf0-c5f7cb9bb847</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#list-data > div:nth-child(1) > div.panel-body > div:nth-child(1) > div.col-sm-9.best-content > div:nth-child(1) > div.col-xs-6.visible-xs > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#list-data > div:nth-child(1) > div.panel-body > div:nth-child(1) > div.col-sm-9.best-content > div:nth-child(1) > div.col-xs-6.visible-xs > a</value>
   </webElementProperties>
</WebElementEntity>
