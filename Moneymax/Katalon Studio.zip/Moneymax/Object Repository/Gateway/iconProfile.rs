<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>iconProfile</name>
   <tag></tag>
   <elementGuidId>b8aecf9c-6040-4733-b3a8-543039adf4c7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#userInfo > img</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#userInfo > img</value>
   </webElementProperties>
</WebElementEntity>
