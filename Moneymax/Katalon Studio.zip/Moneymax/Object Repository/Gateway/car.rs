<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>car</name>
   <tag></tag>
   <elementGuidId>8209e001-6841-4146-b842-2429a8271404</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#main-menu > ul > li.menu.open > ul > li:nth-child(1) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#main-menu > ul > li.menu.open > ul > li:nth-child(1) > a</value>
   </webElementProperties>
</WebElementEntity>
