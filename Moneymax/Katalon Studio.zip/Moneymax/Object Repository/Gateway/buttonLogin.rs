<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>buttonLogin</name>
   <tag></tag>
   <elementGuidId>5fb5e4d7-c3cc-4e8d-a9a1-2d1cc7d71cc6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#body > div.gx-container > div > div > div > div > div > div.login-form > form > fieldset > button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#body > div.gx-container > div > div > div > div > div > div.login-form > form > fieldset > button</value>
   </webElementProperties>
</WebElementEntity>
