<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>LoanAmount</name>
   <tag></tag>
   <elementGuidId>2f2b349c-7f73-43c2-a012-de9f02808a66</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>&lt;input type=&quot;text&quot; id=&quot;loan-amount&quot; class=&quot;form-control price-no-format&quot; name=&quot;&quot; placeholder=&quot;Loan amount&quot;></value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#loan-amount</value>
   </webElementProperties>
</WebElementEntity>
