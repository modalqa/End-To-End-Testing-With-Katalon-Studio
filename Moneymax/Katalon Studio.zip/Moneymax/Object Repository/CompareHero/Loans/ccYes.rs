<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ccYes</name>
   <tag></tag>
   <elementGuidId>2b7af6b0-e403-4ce2-92a3-92a3fc3c85c5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#step4 > div > div:nth-child(1)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#step4 > div > div:nth-child(1)</value>
   </webElementProperties>
</WebElementEntity>
