<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>comapreLoan</name>
   <tag></tag>
   <elementGuidId>ea27f7d3-b0d9-49e8-b415-044f2f7654f3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>body > section.header-content.insurance-page > div > div > div.col-md-12.double-content > div > div > div > div > div > a.btn.btn-success.btn-lg</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>body > section.header-content.insurance-page > div > div > div.col-md-12.double-content > div > div > div > div > div > a.btn.btn-success.btn-lg</value>
   </webElementProperties>
</WebElementEntity>
