<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>nationality</name>
   <tag></tag>
   <elementGuidId>19b32051-224b-4961-a8af-8cc062ba0130</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#personal-info > div > div > div > form > div:nth-child(6) > div > div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#personal-info > div > div > div > form > div:nth-child(6) > div > div</value>
   </webElementProperties>
</WebElementEntity>
