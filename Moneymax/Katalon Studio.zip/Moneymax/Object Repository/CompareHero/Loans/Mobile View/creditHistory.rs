<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>creditHistory</name>
   <tag></tag>
   <elementGuidId>ee2c3b36-2e32-4671-ac43-cb7385774b7d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#credit_status > option:nth-child(1)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#credit_status > option:nth-child(1)</value>
   </webElementProperties>
</WebElementEntity>
