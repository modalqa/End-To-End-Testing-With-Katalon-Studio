<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>findLoan</name>
   <tag></tag>
   <elementGuidId>9866b72a-c1f5-46bb-a0ae-bf34d0537745</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>body > section.header-content.insurance-page > div > div > div.col-md-12.double-content > div > div > div > div > div > a.btn.btn-success.btn-lg</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>body > section.header-content.insurance-page > div > div > div.col-md-12.double-content > div > div > div > div > div > a.btn.btn-success.btn-lg</value>
   </webElementProperties>
</WebElementEntity>
