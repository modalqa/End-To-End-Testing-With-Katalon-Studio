<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>howLongCJ</name>
   <tag></tag>
   <elementGuidId>f794d560-86ed-4bb7-bdbb-228f2465cc38</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#current_job > div > div > div > div:nth-child(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#current_job > div > div > div > div:nth-child(2)</value>
   </webElementProperties>
</WebElementEntity>
