<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>longWorking</name>
   <tag></tag>
   <elementGuidId>9cfb8aa8-df9d-477a-ab6e-5bd5fa3485b3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#current_job > option:nth-child(1)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#current_job > option:nth-child(1)</value>
   </webElementProperties>
</WebElementEntity>
