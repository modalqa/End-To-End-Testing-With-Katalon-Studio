<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>buttonCompare</name>
   <tag></tag>
   <elementGuidId>9aefa747-3949-4c52-ab42-d5137d14e28c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>body > section.header-content.insurance-page > div > div > div.col-md-12.double-content > div > div > div > div > div > a.btn.btn-success.btn-lg</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>body > section.header-content.insurance-page > div > div > div.col-md-12.double-content > div > div > div > div > div > a.btn.btn-success.btn-lg</value>
   </webElementProperties>
</WebElementEntity>
