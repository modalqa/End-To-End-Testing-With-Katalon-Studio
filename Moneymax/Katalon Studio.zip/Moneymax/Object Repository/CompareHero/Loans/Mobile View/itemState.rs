<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>itemState</name>
   <tag></tag>
   <elementGuidId>d660e1ef-f8da-43d1-9196-e03cf6aa75db</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#personal-info > div > div > div > form > div:nth-child(7) > div > div > #state_of_staying > option:nth-child(1)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#personal-info > div > div > div > form > div:nth-child(7) > div > div > #state_of_staying > option:nth-child(1)</value>
   </webElementProperties>
</WebElementEntity>
