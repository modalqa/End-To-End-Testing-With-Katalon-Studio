<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>applyLoan</name>
   <tag></tag>
   <elementGuidId>2e36a812-a811-4ad2-80f8-721edec0b898</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#list-data > div:nth-child(1) > div.panel-body.card-product-body > div:nth-child(1) > div.col-sm-4.col-sm-push-8.col-md-3.col-md-push-9.wrapper-right > div.hidden-xs.hidden-sm.text-center > button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#list-data > div:nth-child(1) > div.panel-body.card-product-body > div:nth-child(1) > div.col-sm-4.col-sm-push-8.col-md-3.col-md-push-9.wrapper-right > div.hidden-xs.hidden-sm.text-center > button</value>
   </webElementProperties>
</WebElementEntity>
