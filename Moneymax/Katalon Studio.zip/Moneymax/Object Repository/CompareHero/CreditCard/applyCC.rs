<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>applyCC</name>
   <tag></tag>
   <elementGuidId>23587235-1a3d-41b6-a93e-1a16f612e6b7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#list-data > div:nth-child(1) > div.panel-body > div:nth-child(1) > div.col-sm-3.text-right.card-box > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#list-data > div:nth-child(1) > div.panel-body > div:nth-child(1) > div.col-sm-3.text-right.card-box > a</value>
   </webElementProperties>
</WebElementEntity>
