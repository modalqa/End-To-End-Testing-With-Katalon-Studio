<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>itemAnnualIncome</name>
   <tag></tag>
   <elementGuidId>61bfb8cd-0abc-4ad4-a86a-c6f7a3a07040</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#collapse1 > form > div:nth-child(1) > div > select > option:nth-child(7)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#collapse1 > form > div:nth-child(1) > div > select > option:nth-child(7)</value>
   </webElementProperties>
</WebElementEntity>
