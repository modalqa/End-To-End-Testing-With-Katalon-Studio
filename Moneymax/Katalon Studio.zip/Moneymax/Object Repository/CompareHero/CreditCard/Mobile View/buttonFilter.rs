<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>buttonFilter</name>
   <tag></tag>
   <elementGuidId>5b4dd151-cc5d-4be8-a2c5-a5df66aaf7cc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#filter > div > div > div > button.btn.btn-warning.btn-main.btn-lg</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#filter > div > div > div > button.btn.btn-warning.btn-main.btn-lg</value>
   </webElementProperties>
</WebElementEntity>
