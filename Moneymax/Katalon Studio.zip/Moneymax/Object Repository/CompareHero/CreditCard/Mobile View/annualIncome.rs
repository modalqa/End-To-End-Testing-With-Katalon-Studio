<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>annualIncome</name>
   <tag></tag>
   <elementGuidId>0fc0503d-d90a-474e-abb9-ffc5f0fe587e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#filter > div > div > div > div:nth-child(4) > div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#filter > div > div > div > div:nth-child(4) > div</value>
   </webElementProperties>
</WebElementEntity>
