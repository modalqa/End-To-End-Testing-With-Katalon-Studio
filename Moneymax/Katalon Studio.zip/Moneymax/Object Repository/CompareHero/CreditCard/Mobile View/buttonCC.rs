<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>buttonCC</name>
   <tag></tag>
   <elementGuidId>d4d4074c-07e1-4c91-a266-19d9537c6c61</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>body > section.header-content.no_background.no_filter > div > div > div.col-sm-8.col-md-6.three-box > div > div:nth-child(1) > div > div > a.btn.btn-success.btn-full</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>body > section.header-content.no_background.no_filter > div > div > div.col-sm-8.col-md-6.three-box > div > div:nth-child(1) > div > div > a.btn.btn-success.btn-full</value>
   </webElementProperties>
</WebElementEntity>
