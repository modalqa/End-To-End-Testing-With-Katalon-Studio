<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>iconFilter</name>
   <tag></tag>
   <elementGuidId>86566344-43a0-4c49-8977-54bb88856ed1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>body > div.background-01.best-deal-page.best-page > div.container-fluid > div > div.breadcrumb-header > div > div > div:nth-child(3) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>body > div.background-01.best-deal-page.best-page > div.container-fluid > div > div.breadcrumb-header > div > div > div:nth-child(3) > a</value>
   </webElementProperties>
</WebElementEntity>
