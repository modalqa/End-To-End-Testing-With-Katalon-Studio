<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>BPO</name>
   <tag></tag>
   <elementGuidId>8457eafb-dd43-4c96-b86e-19e42905269a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>body > section > div > div > div > div.row.left-detail > div:nth-child(1) > div > ul > label:nth-child(4)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>body > section > div > div > div > div.row.left-detail > div:nth-child(1) > div > ul > label:nth-child(4)</value>
   </webElementProperties>
</WebElementEntity>
