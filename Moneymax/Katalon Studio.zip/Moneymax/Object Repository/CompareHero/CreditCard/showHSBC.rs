<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>showHSBC</name>
   <tag></tag>
   <elementGuidId>21ca8142-1aa6-4508-84c3-417e8f3bee25</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#collapse1 > form > div.form-group.credit_card_filter_provider > div:nth-child(14) > label > input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#collapse1 > form > div.form-group.credit_card_filter_provider > div:nth-child(14) > label > input</value>
   </webElementProperties>
</WebElementEntity>
