<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>menuCC</name>
   <tag></tag>
   <elementGuidId>c2c8562b-946a-4d69-864f-cf8c0ed9ca53</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#navbar > ul.nav.navbar-nav.navbar-custom > li:nth-child(1) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#navbar > ul.nav.navbar-nav.navbar-custom > li:nth-child(1) > a</value>
   </webElementProperties>
</WebElementEntity>
