<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>itemActiveCard</name>
   <tag></tag>
   <elementGuidId>6d851741-4ade-4f6a-b028-8823cd577c2b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#active_card > div > div > #active_card_qa > option:nth-child(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#active_card > div > div > #active_card_qa > option:nth-child(2)</value>
   </webElementProperties>
</WebElementEntity>
