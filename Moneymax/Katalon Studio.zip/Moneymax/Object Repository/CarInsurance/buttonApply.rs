<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>buttonApply</name>
   <tag></tag>
   <elementGuidId>17add0ee-a089-4e58-86ca-e3064259cfd3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#list-data > div:nth-child(1) > div.panel-body.card-product-body > div:nth-child(1) > div.col-sm-4.col-sm-push-8.col-md-3.col-md-push-9.wrapper-right > div.hidden-xs.hidden-sm.text-center > button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#list-data > div:nth-child(1) > div.panel-body.card-product-body > div:nth-child(1) > div.col-sm-4.col-sm-push-8.col-md-3.col-md-push-9.wrapper-right > div.hidden-xs.hidden-sm.text-center > button</value>
   </webElementProperties>
</WebElementEntity>
