<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>caverageNo</name>
   <tag></tag>
   <elementGuidId>55fa069e-f565-493e-aa9e-bef67f38f408</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>body > section > div > div > div > div.row.left-detail.frame-coverage.hidden-mobile > div:nth-child(1) > div > div > div:nth-child(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>body > section > div > div > div > div.row.left-detail.frame-coverage.hidden-mobile > div:nth-child(1) > div > div > div:nth-child(2)</value>
   </webElementProperties>
</WebElementEntity>
