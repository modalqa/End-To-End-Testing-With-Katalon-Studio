<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Get</name>
   <tag></tag>
   <elementGuidId>bc777bdf-5434-4395-9396-a830a4a62385</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>body > section.header-content.insurance-page > div:nth-child(1) > div > div.col-md-12.double-content > div.col-sm-offset-1.col-sm-10.col-md-offset-5.col-md-2.double-box > div > div > div > div > a.btn.btn-success.btn-lg</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>body > section.header-content.insurance-page > div:nth-child(1) > div > div.col-md-12.double-content > div.col-sm-offset-1.col-sm-10.col-md-offset-5.col-md-2.double-box > div > div > div > div > a.btn.btn-success.btn-lg</value>
   </webElementProperties>
</WebElementEntity>
