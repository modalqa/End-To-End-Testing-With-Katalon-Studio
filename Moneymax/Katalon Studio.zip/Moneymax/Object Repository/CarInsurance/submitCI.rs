<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>submitCI</name>
   <tag></tag>
   <elementGuidId>099179f2-5ff9-45ec-b96a-b6e7ce40bcd2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#personal-info > div > div > div > form > button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#personal-info > div > div > div > form > button</value>
   </webElementProperties>
</WebElementEntity>
