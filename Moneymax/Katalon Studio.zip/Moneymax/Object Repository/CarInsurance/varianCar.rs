<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>varianCar</name>
   <tag></tag>
   <elementGuidId>25c213aa-1e37-46d6-b0bd-8dd1dfbe5bd3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#trim_car > option:nth-child(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#trim_car > option:nth-child(2)</value>
   </webElementProperties>
</WebElementEntity>
