<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>carYear</name>
   <tag></tag>
   <elementGuidId>47aac6d5-1e4c-4580-8012-e0414eaa2dd2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#car_year > option:nth-child(3)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#car_year > option:nth-child(3)</value>
   </webElementProperties>
</WebElementEntity>
