<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>carVariant</name>
   <tag></tag>
   <elementGuidId>6edcec43-a951-421a-8764-4ce7021e9a6b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#trim > div > div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#trim > div > div</value>
   </webElementProperties>
</WebElementEntity>
