<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>coverageNo</name>
   <tag></tag>
   <elementGuidId>84d1f4ad-dbf3-44e1-9f49-1b191b504c66</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>body > section > div > div > div > div.row.left-detail.frame-coverage.hidden-mobile > div:nth-child(1) > div > div > div:nth-child(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>body > section > div > div > div > div.row.left-detail.frame-coverage.hidden-mobile > div:nth-child(1) > div > div > div:nth-child(2)</value>
   </webElementProperties>
</WebElementEntity>
