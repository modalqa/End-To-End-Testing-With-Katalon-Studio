<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>carBrand</name>
   <tag></tag>
   <elementGuidId>5827e9b5-0957-44e2-9d67-4ff88dfdb9ab</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#car-brand > label:nth-child(6)
</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#car-brand > label:nth-child(6)
</value>
   </webElementProperties>
</WebElementEntity>
