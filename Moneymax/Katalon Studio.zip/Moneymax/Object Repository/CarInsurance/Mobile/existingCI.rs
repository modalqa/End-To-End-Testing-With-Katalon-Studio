<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>existingCI</name>
   <tag></tag>
   <elementGuidId>89f94ea4-ae05-4171-aadc-682e13118eec</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>body > section > div > div > div > div.row.left-detail.frame-coverage.hidden-mobile > div:nth-child(2) > div > div > div:nth-child(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>body > section > div > div > div > div.row.left-detail.frame-coverage.hidden-mobile > div:nth-child(2) > div > div > div:nth-child(2)</value>
   </webElementProperties>
</WebElementEntity>
