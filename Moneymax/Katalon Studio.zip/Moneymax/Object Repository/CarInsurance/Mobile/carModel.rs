<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>carModel</name>
   <tag></tag>
   <elementGuidId>567aa0a4-4fe3-482b-85e7-c7882fb2887f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#step2 > div > ul > label:nth-child(4)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#step2 > div > ul > label:nth-child(4)</value>
   </webElementProperties>
</WebElementEntity>
