<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>carYear</name>
   <tag></tag>
   <elementGuidId>c845998e-687a-47b7-b5b8-6f68634ed520</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#step3 > div > div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#step3 > div > div</value>
   </webElementProperties>
</WebElementEntity>
