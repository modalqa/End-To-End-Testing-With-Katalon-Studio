<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>buttonPrivate</name>
   <tag></tag>
   <elementGuidId>6b15ec7d-3171-44c8-a829-685c67ab0ee1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#car-box > div > div:nth-child(1)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#car-box > div > div:nth-child(1)</value>
   </webElementProperties>
</WebElementEntity>
