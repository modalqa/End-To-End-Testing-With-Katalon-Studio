<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>payingNO</name>
   <tag></tag>
   <elementGuidId>0863eda4-8876-470c-8431-e6d6d621025c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#loan > div > div > div:nth-child(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#loan > div > div > div:nth-child(2)</value>
   </webElementProperties>
</WebElementEntity>
