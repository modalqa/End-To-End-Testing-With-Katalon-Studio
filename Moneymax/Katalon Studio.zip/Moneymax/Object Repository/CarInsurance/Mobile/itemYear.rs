<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>itemYear</name>
   <tag></tag>
   <elementGuidId>2400ebab-a730-4157-886e-030bcbcfd017</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#step3 > div > div > #car_year > option:nth-child(3)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#step3 > div > div > #car_year > option:nth-child(3)</value>
   </webElementProperties>
</WebElementEntity>
