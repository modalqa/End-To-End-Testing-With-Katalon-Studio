<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>itemVariant</name>
   <tag></tag>
   <elementGuidId>be741cb3-48db-45d4-a0e7-a150ce359fe3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#trim > div > div > #trim_car > option:nth-child(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#trim > div > div > #trim_car > option:nth-child(2)</value>
   </webElementProperties>
</WebElementEntity>
