<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>carSellect</name>
   <tag></tag>
   <elementGuidId>06ba2928-6d90-4457-a20b-bf3ad65df120</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>body > section > div > div > div > div:nth-child(7) > div:nth-child(1) > div > div.hidden-xs > #car-select > option:nth-child(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>body > section > div > div > div > div:nth-child(7) > div:nth-child(1) > div > div.hidden-xs > #car-select > option:nth-child(2)</value>
   </webElementProperties>
</WebElementEntity>
